import XCTest
import InputReader
import Year2021

class Day16Tests: XCTestCase {
    
    let input = Input("Day16.input", Year2021.bundle)

    func test_part1() {
//        XCTAssertEqual(381699, Day1.findMatch(input: input, value: 2020))
    }
    
    func test_part2() {
//        XCTAssertEqual(111605670, Day1.findMatch2(input: input, value: 2020))
    }
}
