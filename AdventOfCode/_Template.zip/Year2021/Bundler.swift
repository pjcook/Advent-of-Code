import Foundation

public class Year2021 {
    public static let bundle = Bundle(for: Year2021.self)
}
