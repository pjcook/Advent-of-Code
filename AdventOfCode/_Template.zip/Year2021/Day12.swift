import Foundation
import StandardLibraries

public struct Day12 {}
