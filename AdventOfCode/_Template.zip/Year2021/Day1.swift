import Foundation
import StandardLibraries

public struct Day1 {}
