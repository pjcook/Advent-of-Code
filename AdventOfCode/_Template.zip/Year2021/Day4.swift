import Foundation
import StandardLibraries

public struct Day4 {}
