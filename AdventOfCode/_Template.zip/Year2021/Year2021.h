//
//  Year2021.h
//  Year2021
//
//  Created by PJ on 24/11/2021.
//  Copyright © 2021 Software101. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Year2021.
FOUNDATION_EXPORT double Year2021VersionNumber;

//! Project version string for Year2021.
FOUNDATION_EXPORT const unsigned char Year2021VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Year2021/PublicHeader.h>


